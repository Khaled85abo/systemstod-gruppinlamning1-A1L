import React from "react";
import ReactDOM from "react-dom";
import Approuter from "./components/Approute";





ReactDOM.render(<Approuter />, document.getElementById("root"));