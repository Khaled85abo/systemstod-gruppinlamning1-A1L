import React from 'react'

export default function Account() {
    return (
        <div>
            <h1>Account information</h1>
        </div>
    )
}

